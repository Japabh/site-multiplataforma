<?php
    $conn  = mysqli_connect("sql.freedb.tech","freedb_kenzo2024","m8mhcGQ?VfpaRg*","freedb_multi2024");
    mysqli_set_charset($conn,"utf8");
    if (!$conn){
        echo "Erro: ".mysqli_connect_error().PHP_EOL;
    }
?>